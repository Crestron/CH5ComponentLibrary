export declare const createElement: (tagName: string, clsName?: string[], textContent?: string) => HTMLElement;
export declare const formatTime: (seconds?: number) => string;
export declare const decodeString: (textValue: string) => string;
export declare const encodeString: (input: string) => string;
