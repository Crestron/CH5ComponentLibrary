import { ICh5CommonAttributesMediaPlayer } from "../../ch5-common/interfaces/i-ch5-common-attributes-media-player";
export interface ICh5MediaPlayerAttributes extends ICh5CommonAttributesMediaPlayer {
    demoMode: boolean;
    contractName: string;
    useContractForEnable: boolean;
    useContractForShow: boolean;
    useContractForCustomStyle: boolean;
    useContractForCustomClass: boolean;
    receiveStateCRPC: string;
    sendEventCRPC: string;
    receiveStateMessage: string;
    receiveStateRefreshMediaPlayer: string;
    receiveStateDeviceOffline: string;
    receiveStatePlayerName: string;
}
