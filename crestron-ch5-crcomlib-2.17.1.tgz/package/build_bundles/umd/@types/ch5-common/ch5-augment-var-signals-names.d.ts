export declare class Ch5AugmentVarSignalsNames {
    private static getUpdatedAttrIdxPlaceholderValue;
    private static replaceAttrIdxPlaceholder;
    private static iterateAttributesInTemplate;
    private static incrementOrPrependAttrValue;
    private static customIncrementOrPrependAttrValue;
    static differentiateTmplElemsAttrs(templateContent: HTMLElement, contractNamePrefix: string, booleanJoinOffset: number, numericJoinOffset: number, stringJoinOffset: number): void;
    private static addDefaultEntriesForDifferentiation;
    static customDifferentiateTmplElemsAttrs(templateContent: HTMLElement, contractNamePrefix: string, booleanJoinOffset: number, numericJoinOffset: number, stringJoinOffset: number): void;
    static replaceIndexIdInTmplElemsAttrs(documentContainer: HTMLTemplateElement, index: number, indexId: string): void;
    static replaceIndexIdInTmplElemsContent(documentContainer: HTMLElement, index: number, indexId: string): void;
}
