export declare const transitionIneffects: any;
export declare const transitionOuteffects: any;
export declare function setTransition(selectedElement: Element, effectType: string, type: string): void;
export declare function removeTransition(selectedElement: Element, effectType: string, type: string): void;
