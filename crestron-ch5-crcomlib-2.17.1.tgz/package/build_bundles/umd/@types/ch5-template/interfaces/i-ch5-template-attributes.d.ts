import { ICh5CommonAttributesTemplate } from "../../ch5-common/interfaces/i-ch5-common-attributes-template";
import { TCh5TransitionInType, TCh5TransitionOutType } from "./t-ch5-template";
export interface ICh5TemplateAttributes extends ICh5CommonAttributesTemplate {
    templateId: string;
    context: string;
    contractName: string;
    booleanJoinOffset: string;
    numericJoinOffset: string;
    stringJoinOffset: string;
    transitionIn: TCh5TransitionInType | null;
    transitionOut: TCh5TransitionOutType | null;
    transitionDuration: string;
    transitionDelay: string;
}
