export declare type TCh5SelectIconPosition = 'first' | 'last';
export declare type TCh5SelectMode = 'plain' | 'panel';
