export declare type TCh5AnimationSize = 'regular' | 'small' | 'large' | 'x-large';
export declare type TCh5AnimationStyle = 'ring' | 'spinner' | 'roller';
