export interface ICH5ImageModeAttributes {
    url: string;
}
