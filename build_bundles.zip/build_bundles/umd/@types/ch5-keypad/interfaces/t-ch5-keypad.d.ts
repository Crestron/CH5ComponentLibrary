export declare type TCh5KeypadType = 'default' | 'primary' | 'info' | 'text' | 'danger' | 'warning' | 'success' | 'secondary';
export declare type TCh5KeypadShape = 'rounded-rectangle' | 'square' | 'circle';
export declare type TCh5KeypadStretch = 'both' | 'width' | 'height';
export declare type TCh5KeypadTextOrientation = 'top' | 'right' | 'bottom' | 'left';
export declare type TCh5KeypadButtonCreateDTO = {
    indexRef: number;
    name: string;
    major: string;
    minor: string;
    className: string;
    iconClass: string[];
    contractName: string;
    contractKey: string;
    joinCountToAdd: string;
    key: string;
    pressed: boolean;
    [key: string]: any;
};
export declare type TCh5KeypadSize = 'regular' | 'x-small' | 'small' | 'large' | 'x-large';
