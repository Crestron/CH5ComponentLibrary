import { TCh5KeypadButtonCreateDTO } from "./interfaces/t-ch5-keypad";
export declare class CH5KeypadButtonData {
    private static numberTypeBtnCssClass;
    private static miscOneBtnCssClass;
    private static miscTwoBtnCssClass;
    private static specialBtnCssClass;
    static getBtnList(runtimeChildButtonList: {
        [key: string]: TCh5KeypadButtonCreateDTO;
    }, parentContractName: string, sendEventOnClickStartVal: string): TCh5KeypadButtonCreateDTO[];
    static getBtnList_Extra(runtimeChildButtonList: {
        [key: string]: TCh5KeypadButtonCreateDTO;
    }, parentContractName: string, sendEventOnClickStartVal?: string): TCh5KeypadButtonCreateDTO[];
    static getChildBtnDTOFromElement(ele: Element, contractName: string, sendEventOnClickStart: string): TCh5KeypadButtonCreateDTO;
    private static getIndexRefForChildBtn;
    private static getClassNameForChildBtn;
}
