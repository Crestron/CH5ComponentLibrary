export declare type TCh5OverlayPanelPositionOffset = 'top-left' | 'top-center' | 'top-right' | 'bottom-left' | 'bottom-center' | 'bottom-right' | 'left-center' | 'right-center';
export declare type TCh5OverlayPanelOverflow = 'scroll' | 'show';
export declare type TCh5OverlayPanelStretch = 'both' | 'width' | 'height';
