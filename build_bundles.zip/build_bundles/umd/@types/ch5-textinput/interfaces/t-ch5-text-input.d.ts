export declare type TCh5TextInputSize = 'regular' | 'x-small' | 'small' | 'large' | 'x-large';
export declare type TCh5TextInputIconPosition = 'first' | 'last';
export declare type TCh5TextInputStretch = 'fixed' | 'width' | 'content';
export declare type TCh5TextInputTextTransform = 'none' | 'capitalize' | 'uppercase' | 'lowercase';
export declare type TCh5TextInputType = 'text' | 'number' | 'email';
