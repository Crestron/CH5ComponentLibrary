export declare type TCh5SpinnerFeedbackModes = 'direct' | 'submit';
export declare type TCh5SpinnerIconPosition = 'first' | 'last';
