import { Ch5Spinner } from "./ch5-spinner";
export declare class Ch5SpinnerMutationObserver {
    static _observer: MutationObserver;
    constructor(element: Ch5Spinner);
    private registerElement;
    private mutationsCallback;
}
