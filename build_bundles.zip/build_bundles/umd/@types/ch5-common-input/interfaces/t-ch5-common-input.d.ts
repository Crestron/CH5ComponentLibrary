export declare type TCh5CommonInputFeedbackModes = 'direct' | 'submit';
