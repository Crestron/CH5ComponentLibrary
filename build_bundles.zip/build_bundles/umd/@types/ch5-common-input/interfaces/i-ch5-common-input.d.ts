import { ICh5CommonInputAttributes } from "./i-ch5-common-input-attributes";
export interface ICh5CommonInput extends ICh5CommonInputAttributes {
    onclean: string;
    ondirty: string;
}
