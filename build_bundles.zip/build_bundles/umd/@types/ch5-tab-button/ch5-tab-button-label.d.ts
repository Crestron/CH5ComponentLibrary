import { Ch5ButtonListLabelBase } from "./../ch5-button-list/base-classes/ch5-button-list-label-base";
export declare class Ch5TabButtonLabel extends Ch5ButtonListLabelBase {
    static ELEMENT_NAME: string;
    static registerCustomElement(): void;
    connectedCallback(): void;
}
