export interface ICh5TabButtonIndividualButtonAttributes {
    labelInnerHTML: string;
    iconUrl: string;
    iconClass: string;
    onRelease: string;
}
