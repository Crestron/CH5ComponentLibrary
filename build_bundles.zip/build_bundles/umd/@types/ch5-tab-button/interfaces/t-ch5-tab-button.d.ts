export declare type TCh5TabButtonButtonShape = 'rectangle' | 'rounded-rectangle' | 'tab';
export declare type TCh5TabButtonButtonType = 'default' | 'danger' | 'text' | 'warning' | 'info' | 'success' | 'primary' | 'secondary';
export declare type TCh5TabButtonButtonHAlignLabel = 'center' | 'left' | 'right';
export declare type TCh5TabButtonButtonVAlignLabel = 'middle' | 'top' | 'bottom';
export declare type TCh5TabButtonButtonIconPosition = 'first' | 'last' | 'top' | 'bottom';
