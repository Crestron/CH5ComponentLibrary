import { TCh5GenericListAttributesOrientation } from '../../ch5-generic-list-attributes/interfaces/t-ch5-generic-list-attributes';
import { TCh5TabButtonButtonType, TCh5TabButtonButtonHAlignLabel, TCh5TabButtonButtonVAlignLabel, TCh5TabButtonButtonIconPosition, TCh5TabButtonButtonShape } from '../../ch5-tab-button/interfaces/t-ch5-tab-button';
import { ICh5GenericListAttributes } from "../../ch5-common/interfaces/i-ch5-generic-list-attributes";
export interface ICh5TabButtonAttributes extends ICh5GenericListAttributes {
    orientation: TCh5GenericListAttributesOrientation;
    numberOfItems: number;
    indexId: string;
    buttonType: TCh5TabButtonButtonType;
    buttonHAlignLabel: TCh5TabButtonButtonHAlignLabel;
    buttonVAlignLabel: TCh5TabButtonButtonVAlignLabel;
    buttonIconPosition: TCh5TabButtonButtonIconPosition;
    buttonShape: TCh5TabButtonButtonShape;
    buttonSelected: boolean;
    buttonPressed: boolean;
    buttonIconClass: string;
    buttonIconUrl: string;
    buttonReceiveStateSelected: string;
    buttonReceiveStateLabel: string;
    buttonReceiveStateScriptLabelHtml: string;
    buttonReceiveStateIconClass: string;
    buttonReceiveStateIconUrl: string;
    buttonSendEventOnClick: string;
    buttonReceiveStateShow: string;
    buttonReceiveStateEnable: string;
}
