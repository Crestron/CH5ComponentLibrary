export declare class Ch5AttrsLog {
    static info(debug: boolean, message?: any, ...optionalParams: any[]): void;
}
