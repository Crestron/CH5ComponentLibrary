import { ICustomAttribute } from "./helpers/i-custom-attribute";
export interface ICh5AttrsShowPulse extends ICustomAttribute<string> {
}
