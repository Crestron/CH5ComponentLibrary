import { ICustomAttribute } from "./helpers/i-custom-attribute";
import { Ch5AttrShowTypes } from "./t-ch5-attrs";
export interface ICh5AttrsNoshowType extends ICustomAttribute<Ch5AttrShowTypes> {
}
