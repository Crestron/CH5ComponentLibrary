export interface ICustomAttribute<T> {
    type: T;
}
