import { ICustomAttribute } from "./helpers/i-custom-attribute";
export interface ICh5AttrsAppendstyle extends ICustomAttribute<string> {
}
