import { ICustomAttribute } from "./helpers/i-custom-attribute";
export interface ICh5AttrsKeepSigSubscription extends ICustomAttribute<string> {
}
