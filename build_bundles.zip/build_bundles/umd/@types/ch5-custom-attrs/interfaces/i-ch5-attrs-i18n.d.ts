import { ICustomAttribute } from "./helpers/i-custom-attribute";
export interface ICh5AttrsI18n extends ICustomAttribute<string> {
}
