import { ICustomAttribute } from "./helpers/i-custom-attribute";
export interface ICh5AttrsEnable extends ICustomAttribute<string> {
}
