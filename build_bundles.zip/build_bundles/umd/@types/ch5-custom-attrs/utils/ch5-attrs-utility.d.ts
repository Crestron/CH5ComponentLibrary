export declare function randomFixedInteger(numberLength: number): number;
