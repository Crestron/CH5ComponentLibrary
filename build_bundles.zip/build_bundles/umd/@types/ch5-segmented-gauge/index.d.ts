export * from './ch5-segmented-gauge';
