export declare type TCh5SegmentedGaugeOrientation = 'horizontal' | 'vertical';
export declare type TCh5SegmentedGaugeGaugeLedStyle = 'rectangle' | 'circle';
export declare type TCh5SegmentedGaugeStateGraphic = 'green' | 'yellow' | 'red' | 'blue' | 'orange' | 'white' | 'inactive';
