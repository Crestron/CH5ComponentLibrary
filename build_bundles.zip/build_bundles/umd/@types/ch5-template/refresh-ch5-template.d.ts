import { Subject } from "rxjs";
export declare const ch5TemplateSubject: Subject<string>;
export declare const refreshCh5Template: (ch5TemplateId: string) => void;
