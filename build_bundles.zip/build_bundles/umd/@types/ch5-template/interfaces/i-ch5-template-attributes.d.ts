import { ICh5CommonAttributesWoReceiveStateEnable } from "../../ch5-common/interfaces/i-ch5-common-attributes-wo-receivestateenable";
export interface ICh5TemplateAttributes extends ICh5CommonAttributesWoReceiveStateEnable {
    templateId: string;
    context: string;
    contractName: string;
    booleanJoinOffset: string;
    numericJoinOffset: string;
    stringJoinOffset: string;
}
