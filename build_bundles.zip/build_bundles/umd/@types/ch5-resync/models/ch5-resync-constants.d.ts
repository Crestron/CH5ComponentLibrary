export declare class Ch5ResyncConstants {
    static readonly JOIN_NUMBER_SIGNAL_NAME_PREFIX = "fb";
}
