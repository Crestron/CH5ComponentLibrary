export interface ICh5ExcludePrefixesModel {
    excludePrefixes: string[];
}
