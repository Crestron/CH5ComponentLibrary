export declare enum ResetEventNames {
    startOfUpdateRange = "StartOfUpdateRange",
    startOfUpdateRangeSO = "StartOfUpdateRangeSO",
    clearAll = "ClearAll",
    clearRange = "ClearRange",
    endOfUpdate = "EndOfUpdate",
    startOfUpdate = "StartOfUpdate"
}
