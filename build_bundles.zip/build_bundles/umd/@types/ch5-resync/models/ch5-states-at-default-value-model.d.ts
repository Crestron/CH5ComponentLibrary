export declare type ICh5StatesAtDefaultValueModelJoinNames = Record<string, boolean>;
export declare type ICh5StatesAtDefaultValueModel = Record<string, ICh5StatesAtDefaultValueModelJoinNames>;
