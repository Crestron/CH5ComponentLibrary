export declare type TCh5ToggleFeedbackMode = 'direct' | 'submit';
