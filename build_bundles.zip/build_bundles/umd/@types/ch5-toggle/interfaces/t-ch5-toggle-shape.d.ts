export declare type TCh5ToggleShape = 'circle' | 'rectangle';
