export declare type TCh5ToggleOrientation = 'horizontal' | 'vertical';
