export declare function uriSchemaValidation(uri: string): boolean;
