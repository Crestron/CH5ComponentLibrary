import { RemoteAppender } from '../appender/RemoteAppender';
export declare function getRemoteAppender(hostname: string, port: string, secure: boolean): RemoteAppender;
