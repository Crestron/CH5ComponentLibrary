import { ICh5CommonAttributes } from "../../ch5-common/interfaces";
export interface ICh5ImportHtmlSnippetAttributes extends ICh5CommonAttributes {
    url: string;
}
