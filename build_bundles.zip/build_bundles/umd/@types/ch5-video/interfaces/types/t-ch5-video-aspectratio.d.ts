export declare type TCH5VideoAspectRatio = '16:9' | '4:3';
