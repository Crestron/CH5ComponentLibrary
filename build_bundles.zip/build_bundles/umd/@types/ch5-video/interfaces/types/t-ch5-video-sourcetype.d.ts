export declare type TCH5VideoSourceType = 'Network' | 'HDMI' | 'DM';
