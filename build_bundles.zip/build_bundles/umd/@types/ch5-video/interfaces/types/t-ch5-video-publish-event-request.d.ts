export interface ICh5VideoCredentials {
    userid: string;
    password: string;
}
export interface ICh5VideoSource {
    type: string;
    url: string;
}
export interface ICh5VideoLocation {
    top: number;
    left: number;
    width: number;
    height: number;
    z: number;
}
export interface ICh5VideoPublishEvent {
    action: string;
    id: number;
    credentials?: ICh5VideoCredentials;
    source?: ICh5VideoSource;
    location?: ICh5VideoLocation;
    alphablend?: boolean;
    starttime?: number;
    endtime?: number;
    timing?: string;
}
export interface ICh5VideoBackground {
    action: string;
    id: string;
    top: number;
    left: number;
    width: number;
    height: number;
    image?: HTMLImageElement;
}
