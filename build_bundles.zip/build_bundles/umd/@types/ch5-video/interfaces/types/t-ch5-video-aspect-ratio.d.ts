export declare type TDimension = {
    width: number;
    height: number;
};
export declare type TVideoResponse = {
    currenttime: number;
    id: number;
    status: string;
    statusCode: number;
    location: TVideoLocationResponse;
};
export declare type TVideoLocationResponse = {
    height: number;
    left: number;
    top: number;
    width: number;
};
export declare type TPosDimension = {
    width: number;
    height: number;
    posX: number;
    posY: number;
};
export declare type TAspectRatio = {
    "xx-large": TDimension;
    "x-large": TDimension;
    "large": TDimension;
    "small": TDimension;
    "x-small": TDimension;
};
