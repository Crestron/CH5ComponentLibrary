export declare type ITouchOrdinates = {
    startX: number;
    startY: number;
    endX: number;
    endY: number;
};
export declare type TVideoTouchManagerParams = {
    onTouchStartHandler: () => {};
    onTouchMoveHandler: () => {};
    onTouchEndHandler: () => {};
    onTouchCancelHandler: () => {};
    pollingDuration: number;
    componentID: string;
};
