export declare type TCH5VideoSize = 'x-small' | 'small' | 'large' | 'x-large' | 'xx-large';
