export declare type TCH5VideoStretch = 'true' | 'false';
