import { TPosDimension, TDimension, IVideoElementDimensions } from "./interfaces/types";
export declare class CH5VideoUtils {
    static getFullScreenDimensions(aspectRatio: string, width: number, height: number): TPosDimension;
    static getSizeAndPositionForFixedSize: (elem: Element, displaySizeObj: TDimension) => any;
    static getParentElementOffsetAndDimension: (ele: Element) => IVideoElementDimensions;
    private static pad;
    static isPortrait: () => boolean;
    static isLandscape: () => boolean;
    private static timezoneOffset;
    static rfc3339TimeStamp: () => number;
    static getAspectRatioForVideo: (aspectRatio: string, size: string) => {
        width: number;
        height: number;
    };
    static setAttributesBasedValue: (hasAttribute: boolean, valToAssign: any, defaultValue: string) => any;
    static getDisplayWxH: (aRatio: any, width: number, height: number) => {
        width: number;
        height: number;
    };
    static calculatePillarBoxPadding: (availableWidth: number, displayWidth: number) => {
        xPos: number;
        yPos: number;
    };
    static calculateLetterBoxPadding: (availableHeight: number, displayHeight: number) => {
        xPos: number;
        yPos: number;
    };
    static getVideoElementOffset(el: HTMLElement): {
        top: number;
        left: number;
    };
}
