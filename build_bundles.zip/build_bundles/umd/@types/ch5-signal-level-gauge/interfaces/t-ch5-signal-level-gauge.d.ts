export declare type TCh5SignalLevelGaugeOrientation = 'horizontal' | 'vertical';
export declare type TCh5SignalLevelGaugeSize = 'regular' | 'small' | 'large' | 'x-large';
