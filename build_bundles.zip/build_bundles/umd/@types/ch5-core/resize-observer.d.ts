export declare function resizeObserver(node: HTMLElement, callback: any): void;
