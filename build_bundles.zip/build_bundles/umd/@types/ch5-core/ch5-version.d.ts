export declare const version: string;
export declare const buildDate: string;
export declare const signalNameForLibraryVersion: string;
export declare const signalNameForLibraryBuildDate: string;
