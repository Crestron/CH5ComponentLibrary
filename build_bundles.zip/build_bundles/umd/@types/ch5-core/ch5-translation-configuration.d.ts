export declare class Ch5TranslationConfiguration {
    static translationTokenStartDelimiter: string;
    static translationTokenEndDelimiter: string;
}
