import { ICh5PropertySettings, TPropertyTypes } from "./ch5-property";
import { Ch5Common } from "../ch5-common/ch5-common";
import { Ch5Log } from "../ch5-common/ch5-log";
export declare class Ch5Properties {
    ch5Component: Ch5Common | Ch5Log;
    propertiesObject: ICh5PropertySettings[];
    private _properties;
    constructor(ch5Component: Ch5Common | Ch5Log, propertiesObject: ICh5PropertySettings[]);
    unsubscribe(): void;
    get<T>(propertyName: string): T;
    set<T>(propertyName: string, value: TPropertyTypes, callback?: any, signalCallback?: any): void;
    setForSignalResponse<T>(propertyName: string, value: TPropertyTypes, callback?: any, signalCallback?: any): void;
    private isAttributeAvailableInComponent;
    private getPropertyByName;
}
