export declare function textformat(template: string, ...templateParams: any[]): string;
