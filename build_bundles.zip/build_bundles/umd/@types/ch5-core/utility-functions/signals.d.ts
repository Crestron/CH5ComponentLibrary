export declare function getSubscriptionsCount(): any;
