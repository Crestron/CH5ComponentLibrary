import { TSignalNonStandardTypeName, TSignalValue } from "../core";
export declare function publishEvent(signalType: TSignalNonStandardTypeName, signalName: string, value: TSignalValue): void;
