export declare function isSafariMobile(): boolean;
