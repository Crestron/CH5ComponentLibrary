export declare function triggerTranslation(language?: string): void;
