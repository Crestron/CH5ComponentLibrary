export declare function isCrestronDevice(): boolean;
