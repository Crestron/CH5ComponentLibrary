export declare function countNumberOfCh5Components(parentElement: any): any;
