import { i18n } from "i18next";
export declare function registerTranslationInterface(translator: i18n, beginWith?: string, endingWith?: string): void;
