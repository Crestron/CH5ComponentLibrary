export declare function isCrestronTouchscreen(): boolean;
