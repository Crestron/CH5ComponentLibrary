import { TSignalNonStandardTypeName } from "../core";
export declare function unsubscribeState(signalType: TSignalNonStandardTypeName, signalName: string, subscriptionId: string): void;
