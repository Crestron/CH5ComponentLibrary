export declare class Ch5Heartbeats {
    private static _instance;
    private _heartbeatRequestSub;
    private constructor();
    static getInstance(): Ch5Heartbeats;
}
