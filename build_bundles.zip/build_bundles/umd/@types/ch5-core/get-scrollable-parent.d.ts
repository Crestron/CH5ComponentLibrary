export declare function getScrollableParent(node: HTMLElement): HTMLElement;
