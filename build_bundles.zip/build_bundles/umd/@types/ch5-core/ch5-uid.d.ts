export declare class Ch5Uid {
    private static _id;
    private static _prefix;
    static getUid(): string;
}
