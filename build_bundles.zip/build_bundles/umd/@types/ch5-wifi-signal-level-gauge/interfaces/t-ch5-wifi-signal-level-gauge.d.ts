export declare type TCh5WifiSignalLevelGaugeGaugeStyle = 'light' | 'accents' | 'dark';
export declare type TCh5WifiSignalLevelGaugeAlignment = 'up' | 'down' | 'left' | 'right';
export declare type TCh5WifiSignalLevelGaugeSize = 'regular' | 'small' | 'large' | 'x-large';
