export declare type TCh5GenericListAttributesOrientation = 'horizontal' | 'vertical';
export declare type TCh5GenericListAttributesStretch = 'both';
