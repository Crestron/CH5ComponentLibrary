import { ICh5GenericListAttributes } from "../../ch5-common/interfaces/i-ch5-generic-list-attributes";
import { TCh5GenericListAttributesOrientation, TCh5GenericListAttributesStretch } from './t-ch5-generic-list-attributes';
export interface ICh5GenericListAttributesAttributes extends ICh5GenericListAttributes {
    orientation: TCh5GenericListAttributesOrientation;
    scrollbar: boolean;
    centerItems: boolean;
    stretch: TCh5GenericListAttributesStretch | null;
    endless: boolean;
    numberOfItems: number;
    rows: number;
    columns: number;
    indexId: string;
    receiveStateNumberOfItems: string;
    scrollToPosition: number;
    receiveStateScrollToPosition: string;
}
