export declare type TCh5SelectOptionIconPosition = 'first' | 'last';
