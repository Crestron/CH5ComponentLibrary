export declare const noop: () => undefined;
