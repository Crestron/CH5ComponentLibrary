export declare function AddInitialTick(fn: Function): void;
export declare function AddPreTick(fn: Function): void;
export declare function AddTick(fn: Function): void;
