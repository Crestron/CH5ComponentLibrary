import { TBoolAttribute } from "./t-ch5-common";
export interface ICh5Gestureable {
    gestureable: TBoolAttribute;
}
