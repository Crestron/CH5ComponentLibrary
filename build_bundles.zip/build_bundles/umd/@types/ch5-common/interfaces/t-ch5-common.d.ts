export declare type TBoolAttribute = 'false' | 'true';
export declare type TCh5ShowType = 'visibility' | 'display' | 'remove';
export declare type TCh5ProcessUriParams = {
    protocol: string;
    user: string;
    password: string;
    url: string;
};
export declare type TCh5CreateReceiveStateSigParams = {
    caller: any;
    attrKey: string;
    value: string;
    callbackOnSignalReceived: (val: string | boolean) => void;
};
