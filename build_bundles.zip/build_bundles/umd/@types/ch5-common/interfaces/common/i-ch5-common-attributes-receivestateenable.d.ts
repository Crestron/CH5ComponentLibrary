export interface ICh5CommonAttributesForReceiveStateEnable {
    receiveStateEnable: string;
}
