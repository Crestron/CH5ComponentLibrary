export interface ICh5CommonAttributesForAppendClassWhenInViewPort {
    appendClassWhenInViewPort: string;
}
