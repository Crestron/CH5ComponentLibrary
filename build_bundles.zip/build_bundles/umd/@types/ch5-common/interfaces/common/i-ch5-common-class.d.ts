export interface ICh5CommonForClass {
    class: string;
}
