export interface ICh5CommonAttributesForReceiveStateShowPulse {
    receiveStateShowPulse: string;
}
