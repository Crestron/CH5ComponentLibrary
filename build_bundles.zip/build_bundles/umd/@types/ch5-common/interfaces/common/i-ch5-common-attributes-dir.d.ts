export interface ICh5CommonAttributesForDir {
    dir: string;
}
