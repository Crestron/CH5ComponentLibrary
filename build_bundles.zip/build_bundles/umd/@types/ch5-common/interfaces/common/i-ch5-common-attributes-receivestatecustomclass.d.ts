export interface ICh5CommonAttributesForReceiveStateCustomClass {
    receiveStateCustomClass: string;
}
