export interface ICh5CommonAttributesForReceiveStateShow {
    receiveStateShow: string;
}
