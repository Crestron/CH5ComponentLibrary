import { TCh5ShowType } from "./../t-ch5-common";
export interface ICh5CommonAttributesForNoShowType {
    noshowType: TCh5ShowType;
}
