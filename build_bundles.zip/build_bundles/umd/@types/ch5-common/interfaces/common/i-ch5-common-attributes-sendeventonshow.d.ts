export interface ICh5CommonAttributesForSendEventOnShow {
    sendEventOnShow: string;
}
