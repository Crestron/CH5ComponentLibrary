export interface ICh5CommonAttributesForShow {
    show: boolean;
}
