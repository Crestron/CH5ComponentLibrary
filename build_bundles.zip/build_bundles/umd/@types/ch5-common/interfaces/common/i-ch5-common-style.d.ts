export interface ICh5CommonForStyle {
    style: string;
}
