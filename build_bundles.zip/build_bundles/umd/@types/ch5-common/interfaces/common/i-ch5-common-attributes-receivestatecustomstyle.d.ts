export interface ICh5CommonAttributesForReceiveStateCustomStyle {
    receiveStateCustomStyle: string;
}
