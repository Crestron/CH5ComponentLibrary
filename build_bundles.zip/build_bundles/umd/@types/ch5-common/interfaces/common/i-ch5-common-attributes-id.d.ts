export interface ICh5CommonAttributesForId {
    id: string;
}
