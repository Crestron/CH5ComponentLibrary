export interface ICh5CommonAttributesForReceiveStateHidePulse {
    receiveStateHidePulse: string;
}
