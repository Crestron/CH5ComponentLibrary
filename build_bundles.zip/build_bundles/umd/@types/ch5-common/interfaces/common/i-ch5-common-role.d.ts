export interface ICh5CommonForRole {
    role: string;
}
