import { TBoolAttribute } from "./../t-ch5-common";
export interface ICh5CommonForDisabled {
    disabled: TBoolAttribute;
}
