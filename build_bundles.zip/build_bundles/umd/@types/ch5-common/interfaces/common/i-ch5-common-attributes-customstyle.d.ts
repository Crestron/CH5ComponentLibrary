export interface ICh5CommonAttributesForCustomStyle {
    customStyle: string;
}
