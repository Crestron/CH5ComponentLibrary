export interface ICh5CommonAttributesForCustomClass {
    customClass: string;
}
