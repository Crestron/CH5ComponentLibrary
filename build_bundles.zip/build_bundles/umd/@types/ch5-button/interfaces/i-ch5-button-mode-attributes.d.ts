import { ICh5ButtonModeCommonAttributes } from "./i-ch5-button-mode-common";
export interface ICh5ButtonModeAttributes extends ICh5ButtonModeCommonAttributes {
}
