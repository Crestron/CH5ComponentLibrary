import { ICh5ButtonModeCommonAttributes } from "./i-ch5-button-mode-common";
import { TCh5ButtonModeState } from "./t-ch5-button";
export interface ICh5ButtonModeStateAttributes extends ICh5ButtonModeCommonAttributes {
    state: TCh5ButtonModeState;
}
