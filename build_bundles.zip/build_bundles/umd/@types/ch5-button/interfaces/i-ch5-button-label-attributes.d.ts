export interface ICh5ButtonLabelAttributes {
}
