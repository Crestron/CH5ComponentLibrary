export declare enum Ch5Alignments {
    Left = "left",
    Right = "right",
    Center = "center",
    Justify = "justify"
}
export declare type TCh5ButtonActionType = 'cancel' | 'submit';
export declare type TCh5ButtonCheckboxPosition = 'left' | 'right';
export declare type TCh5ButtonHorizontalAlignLabel = 'left' | 'right' | 'center';
export declare type TCh5ButtonIconPosition = 'first' | 'last' | 'top' | 'bottom';
export declare type TCh5ButtonOrientation = 'horizontal' | 'vertical';
export declare type TCh5ButtonShape = 'rounded-rectangle' | 'rectangle' | 'tab' | 'circle' | 'oval';
export declare type TCh5ButtonSize = 'regular' | 'x-small' | 'small' | 'large' | 'x-large';
export declare type TCh5ButtonStretch = 'both' | 'width' | 'height';
export declare type TCh5ButtonType = 'default' | 'primary' | 'info' | 'text' | 'danger' | 'warning' | 'success' | 'secondary';
export declare type TCh5ButtonVerticalAlignLabel = 'middle' | 'top' | 'bottom';
export declare type TCh5ButtonModeState = 'normal' | 'pressed' | 'selected';
