import { Ch5ButtonBase } from "./ch5-button-base";
export declare class Ch5Button extends Ch5ButtonBase {
    static readonly ELEMENT_NAME = "ch5-button";
    static registerSignalAttributeTypes(): void;
    static registerSignalAttributeDefaults(): void;
    static registerCustomElement(): void;
    constructor();
}
