import { Ch5SignalFactory } from "../ch5-core";
export declare class CH5DpadUtils {
    static readonly sendEventOnClickSigCountToAdd: {
        up: number;
        down: number;
        left: number;
        right: number;
        center: number;
    };
    static readonly contractSuffix: {
        up: string;
        down: string;
        left: string;
        right: string;
        center: string;
    };
    static getAttributeAsString(thisRef: any, keyToCheck: string, defaultValue?: string): string;
    static getAttributeAsBool(thisRef: any, keyToCheck: string, defaultValue: boolean): boolean;
    static clearComponentContent(thisRef: any): void;
    static isNullOrUndefined(input: any): boolean;
    static setAttributeToElement(thisRef: any, attr: string, defaultValue: string): string;
    static getBoolFromString(str: string): boolean;
    static getImageContainer(imageUrl: string): HTMLSpanElement;
    static getIconContainer(): HTMLSpanElement;
    static getLabelContainer(labelClassName: string): HTMLSpanElement;
    static clearSignalValue(csf: Ch5SignalFactory, obj: any, receiveAttribute: string, signalReceiveAttribute: string): void;
    static setAttributesBasedValue(hasAttribute: boolean, valToAssign: any, defaultValue: string): any;
    static setAttributeValueOnControl(thisRef: any, attrKey: string, value: string, validValues: string[], callback: any): void;
    static createIconTag(thisRef: any): void;
}
