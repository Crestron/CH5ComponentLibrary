export declare type TCh5DpadType = 'default' | 'primary' | 'info' | 'text' | 'danger' | 'warning' | 'success' | 'secondary';
export declare type TCh5DpadShape = 'plus' | 'circle';
export declare type TCh5DpadStretch = 'both' | 'width' | 'height';
export declare type TCh5DpadChildButtonType = 'up' | 'down' | 'left' | 'right' | 'center';
export declare type TCh5DpadButtonClassListType = {
    commonBtnClass: string;
    primaryTagClass: string;
    primaryIconClass: string;
    defaultIconClass: string;
    imageClassName: string;
    defaultArrowClass: string;
};
export declare type TCh5DpadConstructorParam = {
    primaryTagClass: string;
    defaultIconClass: string;
    defaultArrowClass: string;
    btnType: TCh5DpadChildButtonType;
};
export declare type TCh5DpadSize = 'regular' | 'x-small' | 'small' | 'large' | 'x-large';
