import { Ch5DpadChildBase } from "./ch5-dpad-child-base";
import { ICh5DpadChildBaseAttributes } from "./interfaces/i-ch5-dpad-child-base-attributes";
export declare class Ch5DpadButton extends Ch5DpadChildBase implements ICh5DpadChildBaseAttributes {
    static readonly ELEMENT_NAME = "ch5-dpad-button";
    static readonly DEFAULT_ICONS: {
        up: string;
        down: string;
        left: string;
        right: string;
        center: string;
    };
    constructor();
    static registerSignalAttributeTypes(): void;
    static get observedAttributes(): string[];
    attributeChangedCallback(attr: string, oldValue: string, newValue: string): void;
    protected initAttributes(): void;
}
