export declare type TCh5SliderDirection = 'rtl' | 'ltr';
export declare enum TCh5SliderHandle {
    VALUE = 0,
    HIGHVALUE = 1
}
export declare type TCh5SliderOrientation = 'horizontal' | 'vertical';
export declare type TCh5SliderShape = 'rounded-rectangle' | 'rectangle' | 'circle' | 'oval';
export declare type TCh5SliderSize = 'regular' | 'x-small' | 'small' | 'large' | 'x-large';
export declare type TCh5SliderStretch = 'both' | 'width' | 'height';
export declare type TCh5SliderTooltipDisplay = '%' | 'value';
export declare type TCh5SliderTooltipType = 'off' | 'on' | 'auto';
export declare type TCh5SliderHorizontalAlignLabel = 'left' | 'right' | 'center';
export declare type TCh5SliderType = 'default' | 'primary' | 'info' | 'text' | 'danger' | 'warning' | 'success' | 'secondary';
export declare type TCh5SliderVerticalAlignLabel = 'middle' | 'top' | 'bottom';
