import { Ch5Animation } from './ch5-animation';
export declare class Ch5AnimationFactory {
    getAnimation(duration: number, easeMode: string, wrapper: HTMLElement): Ch5Animation;
}
