export declare function getEvtListenerOptions(isPassive: boolean): false | {
    passive: boolean;
};
