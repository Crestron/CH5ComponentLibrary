export declare type TCh5ListElementOrientation = 'vertical' | 'horizontal';
