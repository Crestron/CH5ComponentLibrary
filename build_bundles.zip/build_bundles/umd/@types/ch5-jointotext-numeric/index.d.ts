export * from './ch5-jointotext-numeric';
