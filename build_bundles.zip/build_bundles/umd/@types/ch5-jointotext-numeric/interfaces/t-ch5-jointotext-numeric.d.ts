export declare type TCh5JoinInfoNumericFormats = 'signed' | 'float' | 'percentage' | 'hex' | 'raw' | 'unsigned' | 'time';
