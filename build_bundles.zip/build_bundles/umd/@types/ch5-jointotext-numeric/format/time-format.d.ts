import { NumericFormat } from "./numeric-format";
export declare type TimeFormatOptions = {};
export declare class TimeFormat extends NumericFormat {
    format(value: number, options: TimeFormatOptions): string;
}
