import { NumericFormat } from "./numeric-format";
export declare type RawFormatOptions = {};
export declare class RawFormat extends NumericFormat {
    format(value: number, options: RawFormatOptions): string;
}
