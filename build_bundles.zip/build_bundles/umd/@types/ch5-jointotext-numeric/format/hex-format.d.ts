import { NumericFormat } from "./numeric-format";
export declare type HexFormatOptions = {
    length: number;
};
export declare class HexFormat extends NumericFormat {
    format(value: number, options: HexFormatOptions): string;
}
