export declare abstract class NumericFormat {
    abstract format(value: number, options: {}): string | number;
}
