export declare type TCh5BackgroundRepeat = 'no-repeat' | 'repeat' | 'repeat-x' | 'repeat-y';
export declare type TCh5BackgroundScale = 'stretch' | 'fill' | 'fit';
export declare type TCh5BackgroundTransitionEffect = 'ease' | 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';
