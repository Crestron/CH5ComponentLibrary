export declare type TCh5SubpageReferenceListStretch = 'both';
export declare type TCh5SubpageReferenceListOrientation = 'horizontal' | 'vertical';
