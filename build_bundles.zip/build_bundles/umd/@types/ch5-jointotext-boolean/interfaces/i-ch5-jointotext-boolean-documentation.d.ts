import { ICh5Common } from "../../ch5-common/interfaces";
import { ICh5JoinToTextBooleanAttributes } from "./i-ch5-jointotext-boolean-attributes";
export interface ICh5JoinToTextBooleanDocumentation extends ICh5Common, ICh5JoinToTextBooleanAttributes {
}
