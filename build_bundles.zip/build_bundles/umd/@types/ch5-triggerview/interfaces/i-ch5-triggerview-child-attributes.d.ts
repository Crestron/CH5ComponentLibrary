import { ICh5CommonAttributes } from "../../ch5-common/interfaces";
export interface ICh5TriggerViewChildAttributes extends ICh5CommonAttributes {
    sendEventOnShow: string;
    receiveStateShow: string;
}
