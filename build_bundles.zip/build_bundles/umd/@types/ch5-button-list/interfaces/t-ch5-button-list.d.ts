export declare type TCh5ButtonListButtonType = 'default' | 'danger' | 'text' | 'warning' | 'info' | 'success' | 'primary' | 'secondary';
export declare type TCh5ButtonListButtonHAlignLabel = 'center' | 'left' | 'right';
export declare type TCh5ButtonListButtonVAlignLabel = 'middle' | 'top' | 'bottom';
export declare type TCh5ButtonListButtonCheckboxPosition = 'left' | 'right';
export declare type TCh5ButtonListButtonIconPosition = 'first' | 'last' | 'top' | 'bottom';
export declare type TCh5ButtonListButtonShape = 'rectangle' | 'rounded-rectangle';
export declare type TCh5ButtonListButtonModeState = 'normal' | 'pressed' | 'selected';
