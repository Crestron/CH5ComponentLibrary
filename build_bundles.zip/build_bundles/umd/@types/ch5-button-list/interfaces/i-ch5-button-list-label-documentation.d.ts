export interface ICh5ButtonListLabelDocumentation {
}
