import { ICh5GenericListAttributesAttributes } from "../../ch5-generic-list-attributes/interfaces";
import { TCh5ButtonListButtonType, TCh5ButtonListButtonHAlignLabel, TCh5ButtonListButtonVAlignLabel, TCh5ButtonListButtonCheckboxPosition, TCh5ButtonListButtonIconPosition, TCh5ButtonListButtonShape } from './t-ch5-button-list';
export interface ICh5ButtonListAttributes extends ICh5GenericListAttributesAttributes {
    buttonType: TCh5ButtonListButtonType;
    buttonHAlignLabel: TCh5ButtonListButtonHAlignLabel;
    buttonVAlignLabel: TCh5ButtonListButtonVAlignLabel;
    buttonCheckboxPosition: TCh5ButtonListButtonCheckboxPosition;
    buttonIconPosition: TCh5ButtonListButtonIconPosition;
    buttonShape: TCh5ButtonListButtonShape;
    buttonCheckboxShow: boolean;
    buttonSelected: boolean;
    buttonPressed: boolean;
    buttonMode: number;
    buttonIconClass: string;
    buttonIconUrl: string;
    buttonLabelInnerHtml: string;
    buttonReceiveStateMode: string;
    buttonReceiveStateSelected: string;
    buttonReceiveStateLabel: string;
    buttonReceiveStateScriptLabelHtml: string;
    buttonReceiveStateIconClass: string;
    buttonReceiveStateIconUrl: string;
    buttonSendEventOnClick: string;
    buttonReceiveStateShow: string;
    buttonReceiveStateEnable: string;
}
