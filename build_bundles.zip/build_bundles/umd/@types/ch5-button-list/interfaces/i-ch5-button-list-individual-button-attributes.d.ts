export interface ICh5ButtonListIndividualButtonAttributes {
    labelInnerHTML: string;
    iconUrl: string;
    iconClass: string;
    onRelease: string;
}
