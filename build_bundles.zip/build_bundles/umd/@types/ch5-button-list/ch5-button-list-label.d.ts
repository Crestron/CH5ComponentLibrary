import { Ch5ButtonListLabelBase } from "./base-classes/ch5-button-list-label-base";
export declare class Ch5ButtonListLabel extends Ch5ButtonListLabelBase {
    static ELEMENT_NAME: string;
    static registerCustomElement(): void;
    connectedCallback(): void;
}
